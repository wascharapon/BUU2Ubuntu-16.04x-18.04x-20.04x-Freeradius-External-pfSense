<html>
<head>
<title> Insert Data To User Table </title>
</head>
<body>
<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
//Change For Rou
$link = mysqli_connect("localhost", "User-mysql", "password", "database");
//end  Change

            mysqli_set_charset($link, 'utf8');
                        date_default_timezone_set('Asia/Bangkok');
$attribute = "Cleartext-Password";
$op = ":=";
#require_once('db_connection.php');
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Escape user inputs for security
$username = mysqli_real_escape_string($link, $_REQUEST['username']);
//$attribute = mysqli_real_escape_string($link, $_REQUEST['attribute']);
//$op = mysqli_real_escape_string($link, $_REQUEST['op']);
$value = mysqli_real_escape_string($link, $_REQUEST['value']);
$fullname = mysqli_real_escape_string($link, $_REQUEST['fullname']);
$status = mysqli_real_escape_string($link, $_REQUEST['status']);
// Attempt insert query execution
$sql = "INSERT INTO radcheck (username, attribute, op, value, fullname, status) VALUES ('$username', '$attribute', '$op', '$value', '$fullname', '$status')";
if(mysqli_query($link, $sql)){
//    echo "Records added successfully.";
    echo "<meta http-equiv='refresh' content='1;url=index99.php'>"; //index.php   ^d        ^a        ^y  ^t     ^y  ^i     ^w     ^h  ^h     ^c     ^i refresh   ^d  ^{
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>
</body>
</html>
