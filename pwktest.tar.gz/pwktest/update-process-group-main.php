<?php
session_start();
// function to connect and execute the query
//Change For Rou
        $serverName = "localhost";
        $userName = "User-mysql";
        $userPassword = "password";
        $dbName = "database";
//end  Change
        $glimited = "0";
   	$gstatus = "1";
        $conn = mysqli_connect($serverName,$userName,$userPassword,$dbName);

    //$conn = mysqli_connect("localhost", "radiuspwk", "bnsth26171115", "radius");
   mysqli_set_charset($conn, "utf8");
   if(count($_POST)>0) {
   mysqli_query($conn,"UPDATE groups set gid='" . $_POST['gid'] . "', gdesc='" . $_POST['gdesc'] . "', gname='" . $_POST['gname'] . "', gdownload='" . $_POST['gdownload'] . "', gupload='" . $_POST['gupload'] . "', gexpire='" . $_POST['gexpire'] . "'  WHERE gid='" . $_POST['gid'] . "'");
   //$message = "Record Modified Successfully";
   echo "<meta http-equiv='refresh' content='1;url=search_group.php'>";
}
   $result = mysqli_query($conn,"SELECT * FROM groups WHERE gid='" . $_GET['gid'] . "'");
   $row= mysqli_fetch_array($result);
?>

<html>
<head>
<title>Update Main Group</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link href="style_search.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
</head>
<body>
<center>
<form name="frmMainGroup" method="post" action="">
<div><?php if(isset($message)) { echo $message; } ?>
</div>
                  <div>
                                <h1>Update Main Group</h1>
                  </div>        
                        </nav> 
				<h4> 
                        	&nbsp; &nbsp;<a href="home.php"><i class="fas fa-user-circle"></i>Home</a>&nbsp;&nbsp;
                                <a href="index99.php"><i class="fas fa-user-circle"></i>Insert User</a>
                                <a href="index991.php"><i class="fas fa-user-circle"></i>Add Group</a>
                        	&nbsp;&nbsp;<a href="profile.php"><i class="fas fa-user-circle"></i>Profile</a>
                        	&nbsp;&nbsp;<a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
                        	</h4>
                        </nav>
                </div>
<input type="hidden" name="gid" class="txtField" value="<?php echo $row['gid']; ?>">
<br>
ID: <br>
<input type="text" name="gdesc" class="txtField" value="<?php echo $row['gdesc']; ?>">
<br>
GroupName: <br>
<input type="text" name="gname" class="txtField" value="<?php echo $row['gname']; ?>">
<br>
Download: <br>
<input type="text" name="gdownload" class="txtField" value="<?php echo $row['gdownload']; ?>">
<br>
Upload: <br>
<input type="text" name="gupload" class="txtField" value="<?php echo $row['gupload']; ?>">
<br>
Date Expire: <br>
<input type="text" name="gexpire" class="txtField" value="<?php echo $row['gexpire']; ?>">
<br>
<input type="hidden" name="glimited" class="txtField" value="<?php echo $row['glimited']; ?>">
<br>
<input type="hidden" name="gstatus" class="txtField" value="<?php echo $row['gstatus']; ?>">
<br>
<input type="submit" name="submit" value="Submit" class="buttom">
</form>
                       <h1><i>Create By Thitiphan Mutumachan</i></h1>
</center>
</body>
</html>
