<html>
<head><title>Display User Online</title></head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="style_search.css" type="text/css">
<body>
<center>
<div>
                 <nav>
                  <div>
                                <h5>Display User Online</h5>
                  </div>        
                </nav> <h4> 
            &nbsp; &nbsp;<a href="home.php"><i class="fas fa-user-circle"></i>Home</a>&nbsp;&nbsp;
            &nbsp;&nbsp; &nbsp;<a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
        <br /> <br /> <i>Create By Thitiphan Mutumachan</i></h4>
        </nav>
</div>
<?php
session_start();
//Change For Rou
$servername = "localhost";
$username = "User-mysql";
$password = "password";
$dbname = "database";
//end  Change

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
mysqli_set_charset($conn, "utf8");
                        date_default_timezone_set('Asia/Bangkok');

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * from radacct WHERE acctstoptime IS NULL order by acctstarttime desc;";
$que = mysqli_query($conn, $sql);
$res = mysqli_num_rows($que);
$result = $conn->query($sql);
$sum = $res;
$count = $res;
$date = date("d-m-Y");
$time = date("H:i:s");
echo "<center>Total Login Access TO Internet (User Online) : $count </center><br>"; echo "Time&nbsp;Now!&nbsp; : $time&nbsp;&nbsp;Date&nbsp;Now! : $date<br>";

if ($result->num_rows > 0) {
   echo "</br><table border='2'><tr><th>UserName</th><th>&nbsp;&nbsp;IP Address&nbsp;&nbsp;</th><th>&nbsp;&nbsp;Start Session&nbsp;&nbsp;</th><th>&nbsp;&nbsp;Last Activity&nbsp;&nbsp;</th><th>&nbsp;&nbsp;DownLoad&nbsp;&nbsp;</th><th>&nbsp;&nbsp;UpLoad&nbsp;&nbsp;</th></tr>";
  // output data of each row
  while($row = $result->fetch_assoc()) {
    $dw = $row["acctinputoctets"];
    $dw_total = $dw/1048576;
    $dw1 = $row["acctoutputoctets"];
    $dw_total1 = $dw1/1048576;
    echo "<tr><td><center>" .$row["username"]. "</center></td><td>&nbsp;&nbsp;" . $row["framedipaddress"]. "&nbsp;&nbsp;</td><td><center>&nbsp;&nbsp;" . $row["acctstarttime"]. "&nbsp;&nbsp;</td></center><td>&nbsp;&nbsp;" . $row["acctupdatetime"]. "&nbsp;&nbsp;</td><td><center>" . number_format( $dw_total , 2 )."" .' MB' . "</center></td><td><center>" . number_format( $dw_total1 , 2 )."" .' MB' . "</center></td></tr>";
  }
    echo "</table>";
} else {
  echo "0 results";
}
$conn->close();
?>
</center>
</body>
</html>
