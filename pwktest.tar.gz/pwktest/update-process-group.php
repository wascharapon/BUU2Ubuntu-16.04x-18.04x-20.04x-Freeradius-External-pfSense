<?php
session_start();
// function to connect and execute the query
//Change For Rou
        $serverName = "localhost";
        $userName = "User-mysql";
        $userPassword = "password";
        $dbName = "radius";
//end  Change
   	$priority = "1";
        $conn = mysqli_connect($serverName,$userName,$userPassword,$dbName);

    //$conn = mysqli_connect("localhost", "radiuspwk", "bnsth26171115", "radius");
   mysqli_set_charset($conn, "utf8");
   if(count($_POST)>0) {
   mysqli_query($conn,"UPDATE radusergroup set username='" . $_POST['username'] . "', groupname='" . $_POST['groupname'] . "', priority='" . $_POST['priority'] . "'  WHERE username='" . $_POST['username'] . "'");
   //$message = "Record Modified Successfully";
   echo "<meta http-equiv='refresh' content='1;url=search_group_delete.php'>";
}
   $result = mysqli_query($conn,"SELECT * FROM radusergroup WHERE username='" . $_GET['username'] . "'");
   $row= mysqli_fetch_array($result);
?>

<html>
<head>
<title>Update Group Data</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link href="style_search.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
</head>
<body>
<center>
<form name="frmGroup" method="post" action="">
<div><?php if(isset($message)) { echo $message; } ?>
</div>
                  <div>
                                <h1>Update Data Group</h1>
                  </div>        
                        </nav> 
				<h4> 
                        	&nbsp; &nbsp;<a href="home.php"><i class="fas fa-user-circle"></i>Home</a>&nbsp;&nbsp;
                        	&nbsp;&nbsp;<a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
                        	</h4>
                        </nav>
                </div>
UserName: <br>
<input type="text" name="username" class="txtField" value="<?php echo $row['username']; ?>">
<br>
GroupName: <br>
<input type="text" name="groupname" class="txtField" value="<?php echo $row['groupname']; ?>">
<br>
<input type="hidden" name="priority" class="txtField" value="<?php echo $row['priority']; ?>">
<br>
<input type="submit" name="submit" value="Submit" class="buttom">

</form>
                       <h1><i>Create By Thitiphan Mutumachan</i></h1>
</center>
</body>
</html>
