<?php
// We need to use sessions, so you should always start sessions using the below code.
session_start();
// If the user is not logged in redirect to the login page...
///if (!isset($_SESSION['loggedin'])) {
///	header('Location: index.html');
///	exit;
//}
$servername = "localhost";
$username = "radiuspwk";
$password = "bnsth26171115";
$dbname = "radius";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
mysqli_set_charset($conn, "utf8");
                        date_default_timezone_set('Asia/Bangkok');

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
                $sql = "SELECT  username, acctstarttime, framedipaddress, acctupdatetime from radacct WHERE acctstoptime IS NULL;";
                $que1 = mysqli_query($conn, $sql);
                $res1 = mysqli_num_rows($que1);
                $result = $conn->query($sql);
                $sum = $res1;
                $count = $res1;
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Authtication Page For Admin</title>
		<link href="style_home.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
	</head>
	<body class="loggedin">
		<nav class="navtop">
			<div>
				<h1><center>Home Page Authtication</center></h1>
                                <a href="http://10.255.1.249/phpmyadmin/" target="_blank"><i class="fas fa-user-circle"></i>phpMyAdmin</a>
                                <a href="index992.php"><i class="fas fa-user-circle"></i>Add Group</a>
                                <a href="search_group.php"><i class="fas fa-user-circle"></i>List Group</a>
                                <a href="search_group_delete.php"><i class="fas fa-user-circle"></i>User By Group</a>
                                <a href="profile.php"><i class="fas fa-user-circle"></i>Profile</a>
                                <a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
                </div>

			</div>
		</nav>
		<div class="content">
                           <p>Welcome back, <?=$_SESSION['name']?>!<?php echo " Total Login Access Internet(User Online) : $count";?>
                                <p><a href="index99.php"><i class="fas fa-user-circle"></i>Insert User</a><br>
                                <a href="index991.php"><i class="fas fa-user-circle"></i>Add User To Group</a><br>
                                <p><a href="display_groupcheck.phpp"><i class="fas fa-user-circle"></i>Update MaxSession Simultaneous</a><br>
                                <a href="display_groupreply.php"><i class="fas fa-user-circle"></i>Update Session BandWidth</a><br>
                                <a href="search_data_delete.php"><i class="fas fa-user-circle"></i>Search/Update/Delete User</a><br>
                                <p><a href="display_user_online.php"><i class="fas fa-user-circle"></i>User Online</a><br>
                                <a href="display_user_unable.php"><i class="fas fa-user-circle"></i>Radius Reject User</a><br>
		</div>
	</body>
</html>
