<html>
<head>
<title> Insert Group To Table </title>
</head>
<body>
<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
//Change For Rou
$link = mysqli_connect("localhost", "User-mysql", "password", "database");
//end  Change

            mysqli_set_charset($link, 'utf8');
                        date_default_timezone_set('Asia/Bangkok');
$gstatus = "1";
$glimited = "0";
#require_once('db_connection.php');
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Escape user inputs for security
$gname = mysqli_real_escape_string($link, $_REQUEST['gname']);
$gdesc = mysqli_real_escape_string($link, $_REQUEST['gdesc']);
$gupload = mysqli_real_escape_string($link, $_REQUEST['gupload']);
$gdownload = mysqli_real_escape_string($link, $_REQUEST['gdownload']);
$gexpire = mysqli_real_escape_string($link, $_REQUEST['gexpire']);
// Attempt insert query execution
$sql = "INSERT INTO groups (gname, gdesc, gupload, gdownload, gexpire, glimited, gstatus) VALUES ('$gname', '$gdesc', '$gupload', '$gdownload', '$gexpire', '$glimited', '$gstatus')";
if(mysqli_query($link, $sql)){
//    echo "Records added successfully.";
    echo "<meta http-equiv='refresh' content='1;url=index992.php'>"; //index.php   ^d        ^a        ^y  ^t     ^y  ^i     ^w     ^h  ^h     ^c     ^i refresh   ^d  ^{
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>
</body>
</html>
