<?php
session_start();
if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM `groups` WHERE CONCAT(`gid`, `gname`, `gdesc`) LIKE '%".$valueToSearch."%'";
    $search_result = filterTable($query);
}
 else {
    $query = "SELECT * FROM `groups`";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
//Change For Rou
	$serverName = "localhost";
	$userName = "User-mysql";
	$userPassword = "password";
	$dbName = "database";
//end  Change

	$conn = mysqli_connect($serverName,$userName,$userPassword,$dbName);

    //$conn = mysqli_connect("localhost", "radiuspwk", "bnsth26171115", "radius");
    mysqli_set_charset($conn, "utf8");
    $filter_Result = mysqli_query($conn, $query);
    return $filter_Result;
}

?>

<!DOCTYPE html>
<html lang="th">
    <head>
	<meta http-equiv= "Content-Type" content=�"text/html;charset=UTF-8"�>
	<link rel="stylesheet" href="style_search.css">
        <title>Search Group</title>
        <style>
            table,tr,th,td
            {
                border: 1px solid black;
            }
        </style>
    </head>
    <body>
        <center>
        <form action="search_group_delete.php" method="post">
            <input type="text" name="valueToSearch" placeholder="Value To Search"><br><br>
            <input type="submit" name="search" value="Filter"><br><br>
		<div>
                 <nav>
                  <div>
                                <h1>List Main Group</h1>
                  </div>        
                	</nav> <h4> 
            		&nbsp; &nbsp;<a href="home.php"><i class="fas fa-user-circle"></i>Home</a>&nbsp;&nbsp;
                                <a href="index99.php"><i class="fas fa-user-circle"></i>Insert User</a>&nbsp;&nbsp;
                                <a href="index991.php"><i class="fas fa-user-circle"></i>Add User To Group</a>
            		&nbsp;&nbsp; &nbsp;<a href="profile.php"><i class="fas fa-sign-out-alt"></i>Profile</a>
            		&nbsp;&nbsp; &nbsp;<a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
        		<br /> <br /> <i>Create By Thitiphan Mutumachan</i></h4>
        		</nav>
		</div>

            <table>
                <tr>
                    <th>ชื่อกลุ่ม</th>
                    <th>หมายเลข</th>
                    <th>Download</th>
                    <th>Upload</th>
                    <th>วันหมดอายุ</th>
                    <th>Update</th>
                    <th>Delete</th>
                </tr>

      <!-- populate table from mysql database -->
                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr>
                    <td><center><?php echo $row['gdesc'];?></center></td>
                    <td><?php echo $row['gname'];?></td>
                    <td><?php echo $row['gdownload'];?></td>
                    <td><?php echo $row['gupload'];?></td>
                    <td><?php echo $row['gexpire'];?></td>
                    <td><a href="update-process-group-main.php?gid=<?php echo $row["gid"]; ?>">Update</a></td>
                    <td><a href="delete-process-group-main.php?gid=<?php echo $row["gid"]; ?>">Delete</a></td>
                </tr>
                <?php endwhile;?>
            </table>
        </form>
        </center>
    </body>
</html>
