<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link href="style_home.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
<title>INSERT Group To Table</title>
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css'/>
</head>
<body>
<?php
  	session_start();
?>
<div class="container">
<div class="row">
<div class="col-md-4 mx-auto">
<form action="insert992.php" method="post">
<p></p>
<p></p>
<p></p>
                 <nav class="navtop">
                        <div>
                             	<h1><center>Add Group</center></h1>
        	</nav>	
<p></p>
<p></p>
<label for="gname">Group name</label>
<input type="text" name="gname" class="form-control">
</p>
<label for="gdesc">Group description</label>
<input type="char" name="gdesc" class="form-control">
</p>
<label for="gupload">Bandwidth Upload</label>
<input type="int" name="gupload" class="form-control">
</p>
<label for="gdownload">Bandwidth Download</label>
<input type="int" name="gdownload" class="form-control">
</p>
<label for="gexpire">Expire Date (Year-Month-Day) </label>
<input type="date" name="gexpire" class="form-control">
</p>
<button type="submit" class="btn btn-success">บันทึก</button>
</form>
</div>
</div>
</div>
<p></p>
<center>
<div>
<br /> <br /> 
	<nav class="navtop"><br /><h4>
 	    &nbsp; &nbsp;&nbsp; &nbsp;<a href="home.php"><i class="fas fa-user-circle"></i>Home</a>
	    &nbsp; &nbsp;&nbsp; &nbsp;<a href="search_group.php"><i class="fas fa-user-circle"></i>List Group</a>
            &nbsp; &nbsp;&nbsp; &nbsp;<a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
	<br /> <br /> <i>Create By Thitiphan Mutumachan</i></h4>
	</nav>
</div>
</div>
</div>
</center>
</body>
</html>
