<html>
<head>
      	<meta http-equiv= "Content-Type" content= "text/html;charset=UTF-8" >
        <link rel="stylesheet" href="style.css">
        <title>Delete Group data</title>
        <style>
            table,tr,th,td
            {
             	border: 1px solid black;
            }
	</style>
</head>
<body>
<?php
//Change For Rou
     	$serverName = "localhost";
        $userName = "User-mysql";
        $userPassword = "password";
        $dbName = "database";
//end  Change
        $conn = mysqli_connect($serverName,$userName,$userPassword,$dbName);
        mysqli_set_charset($conn, "utf8");
        $result = mysqli_query($conn,"SELECT * FROM radusergroup");
 	$sql = "DELETE FROM radusergroup WHERE username='" . $_GET["username"] . "'";
if (mysqli_query($conn, $sql)) {
    echo "Record deleted successfully";
    echo "<meta http-equiv='refresh' content='1;url=search_group_delete.php'>";
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}
mysqli_close($conn);
?>
</body>
</html>
