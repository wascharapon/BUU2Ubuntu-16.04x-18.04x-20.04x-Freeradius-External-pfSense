<?php
session_start();
// function to connect and execute the query
//Change For Rou
        $serverName = "localhost";
        $userName = "User-mysql";
        $userPassword = "password";
        $dbName = "database";
//end  Change
   	$attribute = "Cleartext-Password";
   	$op = ":=";
        $conn = mysqli_connect($serverName,$userName,$userPassword,$dbName);

    //$conn = mysqli_connect("localhost", "radiuspwk", "bnsth26171115", "radius");
   mysqli_set_charset($conn, "utf8");
   if(count($_POST)>0) {
   mysqli_query($conn,"UPDATE radcheck set id='" . $_POST['id'] . "', fullname='" . $_POST['fullname'] . "', username='" . $_POST['username'] . "', attribute='" . $_POST['attribute'] . "' ,op='" . $_POST['op'] . "' ,value='" . $_POST['value'] . "' ,status='" . $_POST['status'] . "'  WHERE id='" . $_POST['id'] . "'");
   //$message = "Record Modified Successfully";
   echo "<meta http-equiv='refresh' content='1;url=search_data_delete.php'>";
}
   $result = mysqli_query($conn,"SELECT * FROM radcheck WHERE id='" . $_GET['id'] . "'");
   $row= mysqli_fetch_array($result);
?>

<html>
<head>
<title>Update User Data</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link href="style_search.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
</head>
<body>
<center>
<form name="frmUser" method="post" action="">
<div><?php if(isset($message)) { echo $message; } ?>
</div>
                  <div>
                                <h1>Update Data User</h1>
                  </div>        
                        </nav> 
				<h4> 
                        	&nbsp; &nbsp;<a href="home.php"><i class="fas fa-user-circle"></i>Home</a>&nbsp;&nbsp;
                                <a href="index99.php"><i class="fas fa-user-circle"></i>Insert User</a>
                        	&nbsp;&nbsp;<a href="profile.php"><i class="fas fa-user-circle"></i>Profile</a>
                        	&nbsp;&nbsp;<a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
                        	</h4>
                        </nav>
                </div>
<input type="hidden" name="id" class="txtField" value="<?php echo $row['id']; ?>">
<br>
FullName: <br>
<input type="text" name="fullname" class="txtField" value="<?php echo $row['fullname']; ?>">
<br>
UserName :<br>
<input type="text" name="username" class="txtField" value="<?php echo $row['username']; ?>">
<br>
<input type="hidden" name="attribute" class="txtField" value="<?php echo $row['attribute']; ?>">
<input type="hidden" name="op" class="txtField" value="<?php echo $row['op']; ?>">
Password:<br>
<input type="text" name="value" class="txtField" value="<?php echo $row['value']; ?>">
<br>
Status:<br>
<input type="text" name="status" class="txtField" value="<?php echo $row['status']; ?>">
<br>
<input type="submit" name="submit" value="Submit" class="buttom">

</form>
                       <h1><i>Create By Thitiphan Mutumachan</i></h1>
</center>
</body>
</html>
