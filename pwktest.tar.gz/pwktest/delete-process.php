<html>
<head>
      	<meta http-equiv= "Content-Type" content= "text/html;charset=UTF-8" >
        <link rel="stylesheet" href="style.css">
        <title>Delete User data</title>
        <style>
            table,tr,th,td
            {
             	border: 1px solid black;
            }
	</style>
</head>
<body>
<?php
//Change For Rou
        $serverName = "localhost";
        $userName = "User-mysql";
        $userPassword = "password";
        $dbName = "database";
//end  Change

        $conn = mysqli_connect($serverName,$userName,$userPassword,$dbName);
        mysqli_set_charset($conn, "utf8");
        $result = mysqli_query($conn,"SELECT * FROM radcheck");
 	$sql = "DELETE FROM radcheck WHERE id='" . $_GET["id"] . "'";
if (mysqli_query($conn, $sql)) {
    echo "Record deleted successfully";
    echo "<meta http-equiv='refresh' content='1;url=search_data_delete.php'>";
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}
mysqli_close($conn);
?>
</body>
</html>
