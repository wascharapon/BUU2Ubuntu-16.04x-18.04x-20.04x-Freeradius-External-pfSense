<html>
<head><title>Display User Unable to login</title></head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="style_search.css" type="text/css">
<body>
<center>
<div>
                 <nav>
                  <div>
                                <h1>Display User Unable to login</h1>
                  </div>        
                </nav> <h4> 
            &nbsp; &nbsp;<a href="home.php"><i class="fas fa-user-circle"></i>Home</a>&nbsp;&nbsp;
            &nbsp;&nbsp; &nbsp;<a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
        <br /> <br /> <i>Create By Thitiphan Mutumachan</i></h4>
        </nav>
</div>
<?php
session_start();
//Change For Rou
$servername = "localhost";
$username = "User-mysql";
$password = "password";
$dbname = "database";
//end  Change
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
mysqli_set_charset($conn, "utf8");
                        date_default_timezone_set('Asia/Bangkok');

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT * from radpostauth  where  reply  = 'Access-Reject' order by authdate desc";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
   echo "<table border='2'><tr><th>UserName</th><th>&nbsp;&nbsp;Password&nbsp;&nbsp;</th><th>&nbsp;&nbsp;Reply From Server&nbsp;&nbsp;</th><th>&nbsp;&nbsp;Date&Time Login&nbsp;&nbsp;</th></tr>";
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "<tr><td><center>" .$row["username"]. "</center></td><td>&nbsp;&nbsp;" . $row["pass"]. "&nbsp;&nbsp;</td><td><center>&nbsp;&nbsp;" . $row["reply"]. "&nbsp;&nbsp;</td></center><td>&nbsp;&nbsp;" . $row["authdate"]. "&nbsp;&nbsp;</td></tr>";
  }
    echo "</table>";
} else {
  echo "0 results";
}
$conn->close();
?>
</center>
</body>
</html>
