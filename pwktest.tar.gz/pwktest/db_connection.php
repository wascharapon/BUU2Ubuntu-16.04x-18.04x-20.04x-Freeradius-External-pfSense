<?php

function OpenCon()
 {
 $dbhost = "localhost";
 $dbuser = "radiuspwk";
 $dbpass = "bnsth26171115";
 $db = "radiuspwk";


 $conn = new mysqli($dbhost, $dbuser, $dbpass,$db) or die("Connect failed: %s\n". $conn -> error);

 
 return $conn;
 }
 
function CloseCon($conn)
 {
 $conn -> close();
 }
   
?>
