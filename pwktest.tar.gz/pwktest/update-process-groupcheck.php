<?php
session_start();
// function to connect and execute the query
 /* Attempt MySQL server connection. Assuming you are running MySQL
  server with default setting (user 'root' with no password) */
//Change For Rou
        $serverName = "localhost";
        $userName = "User-mysql";
        $userPassword = "password";
        $dbName = "database";
//end  Change
   	$op = ":=";
        $conn = mysqli_connect($serverName,$userName,$userPassword,$dbName);

    //$conn = mysqli_connect("localhost", "radiuspwk", "bnsth26171115", "radius");
   mysqli_set_charset($conn, "utf8");
   if(count($_POST)>0) {
   mysqli_query($conn,"UPDATE  radgroupcheck set id='" . $_POST['id'] . "', groupname='" . $_POST['groupname'] . "', attribute='" . $_POST['attribute'] . "', op='" . $_POST['op'] . "' ,value='" . $_POST['value'] . "'  WHERE id='" . $_POST['id'] . "'");
   //$message = "Record Modified Successfully";
   echo "<meta http-equiv='refresh' content='1;url=display_groupcheck.php'>";
}
   $result = mysqli_query($conn,"SELECT * FROM radgroupcheck WHERE id='" . $_GET['id'] . "'");
   $row= mysqli_fetch_array($result);
?>

<html>
<head>
<title>Update Data</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link href="style_search.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
</head>
<body>
<center>
<form name="frmgroupcheck" method="post" action="">
<div><?php if(isset($message)) { echo $message; } ?>
</div>
                  <div>
                                <h1>Update Data</h1>
                  </div>        
                        </nav> 
				<h4> 
                        	&nbsp; &nbsp;<a href="home.php"><i class="fas fa-user-circle"></i>Home</a>&nbsp;&nbsp;
                                <a href="index99.php"><i class="fas fa-user-circle"></i>Insert User</a>
                        	&nbsp;&nbsp;<a href="profile.php"><i class="fas fa-user-circle"></i>Profile</a>
                        	&nbsp;&nbsp;<a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
                        	</h4>
                        </nav>
                </div>
<input type="hidden" name="id" class="txtField" value="<?php echo $row['id']; ?>">
<br>
Group: <br>
<input type="text" name="groupname" class="txtField" value="<?php echo $row['groupname']; ?>">
<br>
Attribute :<br>
<input type="text" name="attribute" class="txtField" value="<?php echo $row['attribute']; ?>">
<br>
<input type="hidden" name="op" class="txtField" value="<?php echo $row['op']; ?>">
Value:<br>
<input type="text" name="value" class="txtField" value="<?php echo $row['value']; ?>">
<br>
<input type="submit" name="submit" value="Submit" class="buttom">

</form>
                       <h1><i>Create By Thitiphan Mutumachan</i></h1>
</center>
</body>
</html>
